﻿void Jugar()
{
  Console.WriteLine("Juego para buscar un palindromo");
  Console.WriteLine("Ingrese una cadena");
  string text = Console.ReadLine();
  int len = text.Length;
  string validar = IsOk(text, len);

  Console.ReadLine();
}

string IsOk(string text, int len)
{
  for (int i = 0; i < len / 2; i++)
  {
    while (text[i] != text[len - (i + 1)])
    {
      Console.WriteLine($"PERDISTE!! {text} No es Palindromo");
      Palindromo(text);
      Console.WriteLine("Vuelva a ingresar otra palabra");
      text = Console.ReadLine();
      len = text.Length;
    }
  }
  Console.WriteLine($"GANASTE!! {text} si es palindromo!!");
  Palindromo(text);
  return text;
}

string Palindromo(string text)
{
  char[] palindromo = text.ToCharArray();
  Array.Reverse(palindromo);
  string resultadoPalindromo = new string(palindromo);
  Console.WriteLine($"Palabra al reves: {resultadoPalindromo}");
  return resultadoPalindromo;
}

Jugar();