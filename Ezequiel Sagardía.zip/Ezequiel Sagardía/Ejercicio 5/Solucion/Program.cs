﻿using System;
class Cadena
{
  static void Main()
  {
    Analize();
  }

  static void Analize()
  {
    Console.WriteLine("Ingrese una cadena");
    string text = Console.ReadLine();
    int len = text.Length;

    bool ok = IsOk(text, len);
    Console.WriteLine($"'{text}' {(ok ? "" : "no")} está ok");


    Console.ReadLine();
  }

  static bool IsOk(string text, int len)
  {
    for (int i = 0; i < len / 2; i++)
    {
      if (text[i] != text[len - (i + 1)])
      {
        Console.WriteLine($"{text} no es palindromo");
        Palindromo(text);

        return false;
      }
    }
    Console.WriteLine($"{text} si es Palindromo");
    Palindromo(text);
    return true;
  }

  static string Palindromo(string text)
  {
    char[] palindromo = text.ToCharArray();
    Array.Reverse(palindromo);
    string resultadoPalindromo = new string(palindromo);
    Console.WriteLine($"Palabra al reves: {resultadoPalindromo}");
    return resultadoPalindromo;
  }
}