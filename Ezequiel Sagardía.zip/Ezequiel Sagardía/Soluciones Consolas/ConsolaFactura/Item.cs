﻿namespace ConsolaFactura
{
    public class Item
    {
        public int Id { set; get; }
        public decimal Monto { set; get; }
    }
}