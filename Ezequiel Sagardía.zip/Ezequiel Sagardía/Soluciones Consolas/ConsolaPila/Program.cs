﻿using System;
using System.IO.Packaging;

namespace ConsolaPila
{
    class Program
    {
        static void Main(string[] args)
        {
          Pila<int> pilaInts = new Pila<int>();
          Pila<string> pilaStrings = new Pila<string>();
          pilaInts.Push(20);
          pilaInts.Push(50);

          int pila1 = pilaInts.Pop();
          int pila2 = pilaInts.Pop();

          Console.WriteLine($"pila1: {pila1}");
          Console.WriteLine($"pila2: {pila2}");

          pilaStrings.Push("Perro");
          pilaStrings.Push("Gato");

          string pila3 = pilaStrings.Pop();
          string pila4 = pilaStrings.Pop();

          Console.WriteLine($"pila3: {pila3}");
          Console.WriteLine($"pila3: {pila4}");

          Console.ReadLine();
          
        }
    }
}