﻿using System.Collections.Generic;

namespace ConsolaPila
{
    public class Pila<X>
    {
        private readonly List<X> items;

        public Pila()
        {
            items = new List<X>();
        }

        public void Push(X item)
        {
            items.Add(item);
        }

        public X Pop()
        {
            var indiceDelUltimo = items.Count - 1;
            var ultimoItem = items[indiceDelUltimo];
            items.RemoveAt(indiceDelUltimo);

            return ultimoItem;
        }
    }
}
