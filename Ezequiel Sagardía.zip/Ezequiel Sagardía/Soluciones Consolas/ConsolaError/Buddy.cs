﻿namespace ConsolaError
{
    internal class Buddy
    {
        internal int Id { set; get; }
        internal string Name { set; get; }
        internal int Age { set; get; }
    }
}