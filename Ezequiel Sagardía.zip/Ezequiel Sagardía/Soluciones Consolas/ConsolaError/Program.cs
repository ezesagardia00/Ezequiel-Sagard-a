﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ConsolaError
{
  class Program
  {
    static void Main(string[] args)
    {
      var buddiesFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Buddies.txt");

      var buddies = new List<Buddy>();
      //esta linea colocada aca imprimira el archivo Buddies.txt 8 veces: (id 8;Name: Vanesa;edad: 33) 
      //var buddy = new Buddy();

      using (var file = new StreamReader(buddiesFile))
      {
        string line;

        while ((line = file.ReadLine()) != null)
        {
          var data = line.Split(';');
          //al colocarla en el ciclo while imprimira el archivo Buddies.text con los ids del 1 al 8 con su nombre y edad sin repetir ninguno de nuevo
          var buddy = new Buddy();
          //-----------------------------------------------------------------
          buddy.Id = Convert.ToInt32(data[0]);
          buddy.Name = data[1];
          buddy.Age = Convert.ToInt32(data[2]);

          buddies.Add(buddy);
        }
      }

      Console.WriteLine("Buddies:");
      foreach (var b in buddies)
      {
        Console.WriteLine($"Id:{b.Id} - Name:{b.Name} - Age:{b.Age}");
      }

      Console.ReadKey();
    }
  }
}